// @ts-nocheck
import { Plugin } from '/Users/mpf/code/blog/plugins/requestAnimationFrame/node_modules/umi/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','ssr','getInitialState','initialStateConfig','request',],
});

export { plugin };
