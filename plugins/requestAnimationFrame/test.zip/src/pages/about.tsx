
import { Link } from 'umi';

export default function IndexPage() {
  return (
    <div>
      <Link to={'/'}>home</Link>
    </div>
  );
}
